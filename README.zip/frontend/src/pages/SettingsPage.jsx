import React, { useEffect, useState } from 'react';
import {
  Settings,
  Database,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Terminal,
  BookOpen,
  Code2,
  Server,
  Layers,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { fetchHealth } from '../services/api';

export default function SettingsPage() {
  const [healthData, setHealthData] = useState(null);
  const [loadingHealth, setLoadingHealth] = useState(true);
  const [healthError, setHealthError] = useState(null);

  const checkHealth = () => {
    setLoadingHealth(true);
    setHealthError(null);
    fetchHealth()
      .then(res => {
        setHealthData(res);
        setLoadingHealth(false);
      })
      .catch(err => {
        setHealthError(err.message || 'Health check failed');
        setLoadingHealth(false);
      });
  };

  useEffect(() => {
    checkHealth();
  }, []);

  return (
    <div>
      <div className="page-header">
        <div className="page-title-group">
          <h2>Settings & System Information</h2>
          <p>Database connectivity telemetry, architectural design decisions, and placement interview guide</p>
        </div>
      </div>

      {/* Grid: Database Status & Architecture */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px' }}>
        {/* MongoDB Connectivity Card */}
        <div className="card">
          <div className="card-title">
            <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Database size={18} color="#10b981" />
              MongoDB Database Connectivity
            </span>
            <button className="btn btn-secondary btn-sm" onClick={checkHealth}>
              <RefreshCw size={13} className={loadingHealth ? 'animate-spin' : ''} /> Ping DB
            </button>
          </div>

          {loadingHealth ? (
            <p style={{ color: 'var(--text-muted)' }}>Pinging MongoDB...</p>
          ) : healthError ? (
            <div style={{
              background: 'var(--status-failed-bg)',
              border: '1px solid var(--status-failed-border)',
              padding: '12px',
              borderRadius: 'var(--radius-md)',
              color: '#f87171'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600 }}>
                <AlertTriangle size={18} /> Connection Failed
              </div>
              <p style={{ fontSize: '0.84rem', marginTop: '4px' }}>{healthError}</p>
            </div>
          ) : (
            <div>
              <div style={{
                background: 'rgba(16, 185, 129, 0.1)',
                border: '1px solid rgba(16, 185, 129, 0.3)',
                padding: '12px',
                borderRadius: 'var(--radius-md)',
                color: '#10b981',
                marginBottom: '14px'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600 }}>
                  <CheckCircle2 size={18} /> {healthData?.database?.message || 'Connected to MongoDB'}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
                <div style={{ background: 'var(--bg-input)', padding: '10px', borderRadius: 'var(--radius-sm)', textAlign: 'center' }}>
                  <span className="diff-label">Incidents</span>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700, color: '#fff', marginTop: '2px' }}>
                    {healthData?.database?.counts?.incidents ?? 0}
                  </div>
                </div>
                <div style={{ background: 'var(--bg-input)', padding: '10px', borderRadius: 'var(--radius-sm)', textAlign: 'center' }}>
                  <span className="diff-label">Services</span>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700, color: '#fff', marginTop: '2px' }}>
                    {healthData?.database?.counts?.services ?? 0}
                  </div>
                </div>
                <div style={{ background: 'var(--bg-input)', padding: '10px', borderRadius: 'var(--radius-sm)', textAlign: 'center' }}>
                  <span className="diff-label">Events</span>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700, color: '#fff', marginTop: '2px' }}>
                    {healthData?.database?.counts?.events ?? 0}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Tech Stack Specs */}
        <div className="card">
          <div className="card-title">
            <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Server size={18} color="#3b82f6" />
              Environment & Stack Specifications
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.86rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '6px' }}>
              <span style={{ color: 'var(--text-muted)' }}>Frontend Framework:</span>
              <span style={{ color: '#fff', fontWeight: 600 }}>React 18 + Vite 5</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '6px' }}>
              <span style={{ color: 'var(--text-muted)' }}>Backend Server:</span>
              <span style={{ color: '#fff', fontWeight: 600 }}>Python 3.13 Flask (REST API)</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '6px' }}>
              <span style={{ color: 'var(--text-muted)' }}>Database Driver:</span>
              <span style={{ color: '#fff', fontWeight: 600 }}>PyMongo (MongoDB 8.0)</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '6px' }}>
              <span style={{ color: 'var(--text-muted)' }}>Visualization:</span>
              <span style={{ color: '#fff', fontWeight: 600 }}>Interactive SVG Dependency Graph</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--text-muted)' }}>Root-Cause Engine:</span>
              <span style={{ color: '#fff', fontWeight: 600 }}>Deterministic Rule Heuristics</span>
            </div>
          </div>
        </div>
      </div>

      {/* Placement Interview Confidence & Architecture Guide */}
      <div className="card">
        <div className="card-title">
          <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <BookOpen size={18} color="#f59e0b" />
            Interview Talking Points: How to Confidently Explain This Project
          </span>
          <span className="badge badge-info" style={{ textTransform: 'none' }}>
            Placement Preparation
          </span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ background: 'var(--bg-input)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <h4 style={{ fontSize: '0.92rem', color: '#38bdf8', marginBottom: '6px' }}>
              1. What is Failure Replay Lab and what problem does it solve?
            </h4>
            <p style={{ fontSize: '0.86rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              "In microservice architectures, when a high-severity outage strikes, developers are flooded with thousands of disconnected logs. It's often impossible to tell which service caused the root issue and which services simply failed because they called the broken service. Failure Replay Lab act as a <strong>time machine</strong> for software failures: it reconstructs the incident chronologically, visualizes service degradation step-by-step, and uses rule heuristics to distinguish between the earliest symptom, the first service failure, and the suspected root cause."
            </p>
          </div>

          <div style={{ background: 'var(--bg-input)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <h4 style={{ fontSize: '0.92rem', color: '#38bdf8', marginBottom: '6px' }}>
              2. How does the Replay Engine work under the hood in React?
            </h4>
            <p style={{ fontSize: '0.86rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              "The Replay Lab uses a declarative state machine in React: an active index pointer (<code>currentIndex</code>) tracks the revealed event step. A dynamically calculated <code>setTimeout</code> advances the timer based on selected playback speed (1x, 2x, 5x). We explicitly clean up timers on unmount and incident changes to prevent memory leaks and race conditions. At every step, an architectural status reducer computes the state of each node in the SVG dependency graph, marking dependent callers as 'affected' when their upstream dependencies crash."
            </p>
          </div>

          <div style={{ background: 'var(--bg-input)', padding: '14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <h4 style={{ fontSize: '0.92rem', color: '#38bdf8', marginBottom: '6px' }}>
              3. Why did you use Python Flask and PyMongo instead of Node.js?
            </h4>
            <p style={{ fontSize: '0.86rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              "Python provides clean, idiomatic data manipulation and datetime parsing for chronological post-mortem event analysis. Using PyMongo allows direct interaction with MongoDB documents and compound indexing on <code>(incident_id, timestamp)</code>. We built clean separation between database connection pooling (<code>database.py</code>), rule heuristics (<code>root_cause_engine.py</code>), and RESTful blueprints with CORS and JSON serialization."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
